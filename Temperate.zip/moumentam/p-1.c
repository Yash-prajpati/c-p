#include<stdio.h>
main(){
	
	int a;
	
	printf("enter value of a:");
	scanf("%d",&a);
	
	if(a%2==0){
		printf("this no is even");
	}
	else{
		printf("this no is odd");
	}
	
	
}
