#include<stdio.h>
main(){
	
	int n=1,f=10;
	
	
	while(n<=f){
		printf("%d",n);
		n++;
		printf("\n");
	}
	
	
	
}
