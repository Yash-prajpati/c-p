#include<stdio.h>
main(){
	
	int n=1,f=10;
	
	
	while(f>n){
		printf("%d",f);
		f--;
		printf("\n");
	}
	
	
	
}
