#include<stdio.h>
main(){
	
	int n=1,f;
	

	printf("enter ending value:");
	scanf("%d",&f);
	
	
	while(n<=f){
		printf("%d",n);
		n++;
		printf("\n");
	}
	
	
	
}
