#include<stdio.h>
main(){
	
	int c,f;
	
	printf("enter Celsius:-");
	scanf("%d",&c);
	
	f = (c * 9/5) + 32 ;
	
	printf("enter faith:-%d",f);
	
	
	
	
	
	
	
}
