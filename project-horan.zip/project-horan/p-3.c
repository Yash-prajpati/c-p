#include<stdio.h>
main(){
	
	
	int angle1,angle2,angle3;
	
	printf("enter angle1:-");
	scanf("%d",&angle1);
	
	printf("enter angle2:-");
	scanf("%d",&angle2);
	
	
	
	angle3=180- (angle1+angle2);
	
	printf("traiangle:- %d",angle3);

	
	
	
}
