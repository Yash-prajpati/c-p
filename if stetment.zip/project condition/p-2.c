#include<stdio.h>
main(){
	
	int a;
	
	printf("enter your number:-");
	scanf("%d",&a);
	
	if(a%2==0){
		
		printf("this number is odd");
	}
	else{
		printf("this number is even");
		
	}
	
}
