#include<stdio.h>

main(){
	        	        
	        
	 int choice;
	 
	 printf("\t\t Raju Ki Tapri\n");
	 printf("enter your choice :-  ");
	 scanf("%d",&choice);
	 
	 switch(choice){
	 	
	 	printf("menu:");
	 	printf("1:pizza");
	 	printf("2:pasta");
	 	printf("3:burger");
	 	printf("4:frenki");
	 	
	 	
	 	
	 	
	 	case 1:
	 	printf("your order is pizza");
	 	break;
	 	
	 		
	 	case 2:
	 	printf("your order is pasta");
	 	break;
	 	
	 		
	 	case 3:
	 	printf("your order is burger");
	 	break;
	 	
	 	case 4:
	 	printf("your order is frenki");
	 	break;
	 	
	 	default :
	 	printf("please enter valid choice");
	 		
		
	}
}
