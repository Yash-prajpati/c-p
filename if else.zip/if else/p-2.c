#include<stdio.h>
main (){
	int choice ;
	
	printf("enter your choice week:");
	scanf("%d",&choice);
	
	
	
	
	 switch(choice)
	 {
	 	case 1:
	 		printf("frist week");
	 		
	 		break;
	    
	    case 2:
	 		printf("second week");
	 		break;
			 
			 
		case 3:
	 		printf("third week ");
	 		break;
			 
	 	case 4:
	 		printf(" four week");
	 		break;
			 
	
			 
			 default:
			 	printf(" please valid week");	    
	 }
}



