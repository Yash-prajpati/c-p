#include<stdio.h>
main(){
	
	char i='A';
	
	
	do{
			printf("%c",i);
			i+=4;
			
	}while(i<='z');
	
	
}
